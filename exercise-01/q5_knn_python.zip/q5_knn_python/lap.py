import numpy as np
import math

pos = np.arange(-5, 5.0, 0.1)

samples = np.random.normal(0, 1, 100)

dic = {}

dic[0.12323] = 'a'
dic[2] = 'c'

print(dic)
